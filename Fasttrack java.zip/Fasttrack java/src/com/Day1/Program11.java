package com.Day1;
import java.util.*;
public class Program11 {

	public static void main(String[] args) {
		// TODO Aut00o-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter 2 numbers:");
		double a=sc.nextDouble();
		double b=sc.nextDouble();

		double avg=(a+b)/2;
		System.out.println("Average is: "+avg);

	}

}
