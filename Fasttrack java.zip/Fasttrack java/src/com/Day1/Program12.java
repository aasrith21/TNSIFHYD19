package com.Day1;
import java.util.*;
public class Program12 {
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter 2 strings:");
	String a=sc.nextLine();
	String b=sc.nextLine();
	String cont=a+b;
	System.out.println("Concatenated string is "+cont);
}
}
