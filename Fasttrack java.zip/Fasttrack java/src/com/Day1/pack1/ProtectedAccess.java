package com.Day1.pack1;

//import com.Day1.pack2.Y;

class X
{
protected void display()
{
System.out.println("TNS Sessions");
}
}

public class ProtectedAccess extends X{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProtectedAccess obj = new ProtectedAccess();
		obj.display();

	}

}
