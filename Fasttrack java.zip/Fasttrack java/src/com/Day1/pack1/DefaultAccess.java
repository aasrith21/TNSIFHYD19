package com.Day1.pack1;

class MyClass1
{
void display()
{
System.out.println("Hello World!");
}
}
public class DefaultAccess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyClass1 obj= new MyClass1();
		obj.display();

	}

}
