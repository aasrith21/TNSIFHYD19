package com.Day1.pack1;
class myClass
{
public void display()
{
System.out.println("TNS Sessions");
}
}

public class PublicAccess {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		myClass obj = new myClass();
		obj.display();


	}

}
