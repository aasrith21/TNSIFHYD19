package com.si.demo.sprint.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.si.demo.sprint.entity.Employee;
import com.si.demo.sprint.service.EmployeeService;

@RestController
public class EmployeeController {
	@Autowired
    private EmployeeService employeeService;
	
	
	
	 @PostMapping("/employees")
	    public Employee saveEmployee(@RequestBody Employee employee) {
	       
	        return employeeService.saveEmployee(employee);
	    }
	    

	    @GetMapping("/employees")
	    public List<Employee> fetchEmployeeList() {
	        
	        return employeeService.fetchEmployeeList();
	    }
	    


	    @GetMapping("/employees/{id}")
	    public Employee fetchEmployeeById(@PathVariable("id") Long id)
	            {
	        return employeeService.fetchEmployeeById(id);
	    }
	    
	    @DeleteMapping("/employees/{id}")
	    public String deleteEmployeetById(@PathVariable("id") Long id) {
	        employeeService.deleteEmployeeById(id);
	        return "Employee deleted Successfully!!";
	    }
	    
	    @PutMapping("/employees/{id}")
	    public Employee updateEmployee(@PathVariable("id") Long id,
	                                       @RequestBody Employee employee) {
	        return employeeService.updateEmployee(id,employee);
	    }
	
	
	

}
